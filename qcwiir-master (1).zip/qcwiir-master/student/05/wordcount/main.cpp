#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <set>
#include <map>
using namespace std;


std::vector<std::string> split(const std::string& text, char separator, bool ignore_empty = false)
{
    std::vector<std::string> parts;

    std::string::size_type left = 0;
    std::string::size_type right = text.find(separator, left);

    while (right != std::string::npos)
    {
        std::string part = text.substr(left, right - left);

        if (part != "" || !ignore_empty)
        {
            parts.push_back(part);
        }

        left = right + 1;

        right = text.find(separator, left);
    }
    if (text.substr(left, std::string::npos -left) != "" || !ignore_empty)
    {
    parts.push_back(text.substr(left, std::string::npos -left));
    }

    return parts;
}

int main()
{
    string filename;
    cout << "Input file: ";
    cin >> filename;

    ifstream input_file;
    input_file.open(filename);
    if ( not input_file.is_open())
    {
        cout << "Error! The file " << filename << " cannot be opened." << endl;
        return EXIT_FAILURE;
    }
        vector<string> lines;
        string line;
        while(getline(input_file,line))
        {
            lines.push_back(line);
        }
        input_file.close();


        map<string , set<int>> lines_by_word;
        for (size_t i = 0; i < lines.size(); ++i)
        {
            line = lines.at(i);
            vector<string> words = split(line, ' ', true);
            for (size_t j = 0; j < words.size(); j++)
            {
                string word = words.at(j);
                if ( lines_by_word.count(word) == 0)
                {
                    lines_by_word[word] = set<int>();
                }
                lines_by_word[word].insert(static_cast<int>(i)+1);
            }
        }
        for (pair<string, set<int>> key_value_pair : lines_by_word)
        {
            string word = key_value_pair.first;
            set<int> lines = key_value_pair.second;

            cout << word << " " << lines.size() <<": ";
            for (set<int>::iterator current_line = lines.begin(); current_line != lines.end(); ++current_line)
            {
                cout << *current_line;
                if (current_line != --lines.end())
                {
                    cout << ", ";
                }
            }
            cout << endl;
        }
    return EXIT_SUCCESS;

}
