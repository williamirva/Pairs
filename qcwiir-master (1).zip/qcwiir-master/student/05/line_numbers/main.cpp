#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main()
{
    string input_file;
    string output_file;
    cout << "Input file: ";
    cin >> input_file;
    cout << "Output file: ";
    cin >> output_file;

    ifstream read_file_object(input_file);
    if ( not read_file_object )
    {
        cout << "Error! The file " << input_file << " cannot be opened." << endl;
        return EXIT_FAILURE;

    }
    else
    {
        ofstream write_file_object(output_file);
        string line;
        int i = 1;

        while ( getline(read_file_object, line) )
        {
            {
            string num = to_string(i);
            write_file_object << num << " " << line << endl;
            i++;
            }
        }
        read_file_object.close();
        write_file_object.close();
    }
}
