#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <set>
using namespace std;


int main()
{
    string input_file;
    cout << "Input file: ";
    cin >> input_file;
    ifstream file_object(input_file);
    map<string, int> scores;
    set<string> names;
    string line;
    string name;
    string str_points;

    if ( not file_object )
    {
        cout << "Error! The file " << input_file << " cannot be opened." << endl;
        return EXIT_FAILURE;
    }

    else

    {
        cout << "Final scores: " << endl;

        while ( getline(file_object, line) )
        {
            name = line.substr(0, line.find(":"));
            str_points = line.substr(line.find(":")+1, line.find("string::nnpos")-1);
            unsigned int points = stoi(str_points);
            if ( scores.find(name) == scores.end() )
            {
                scores.insert({name, points});
                names.insert(name);
            }
            else
            {
                scores.at(name) += points;
            }
        }
        for (auto info : scores)
        {
            cout << info.first << ": " << info.second << endl;
        }

    }
    file_object.close();
}
