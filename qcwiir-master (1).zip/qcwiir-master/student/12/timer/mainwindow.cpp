#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    timer(new QTimer(this)),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPalette pal = ui->centralWidget->palette();

    pal.setColor(QPalette::Background, Qt::blue);
    ui->lcdNumberMin->setAutoFillBackground(true);
        ui->lcdNumberMin->setPalette(pal);
        ui->lcdNumberMin->show();

        ui->lcdNumberSec->setAutoFillBackground(true);
            ui->lcdNumberSec->setPalette(pal);
            ui->lcdNumberSec->show();

    connect(ui->startButton, &QPushButton::clicked, this, &MainWindow::OnstartButton_clicked);
    connect(ui->stopButton, &QPushButton::clicked, this, &MainWindow::OnstopButton_clicked);
    connect(ui->resetButton, &QPushButton::clicked, this, &MainWindow::OnresetButton_clicked);

    connect(timer, &QTimer::timeout, this, &MainWindow::Ontimer_timeout);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::Ontimer_timeout()
{
    int current_mins = ui->lcdNumberMin->intValue();
    int current_secs = ui->lcdNumberSec->intValue();

    if (current_secs == 59)
    {
        ui->lcdNumberMin->display(current_mins + 1);
        ui->lcdNumberSec->display(0);
    }
    else
    {
        ui->lcdNumberSec->display(current_secs + 1);
    }


}

void MainWindow::OnstartButton_clicked()
{
    timer->start(1000);
}

void MainWindow::OnstopButton_clicked()
{
    timer->stop();
}

void MainWindow::OnresetButton_clicked()
{
    ui->lcdNumberMin->display(0);
    ui->lcdNumberSec->display(0);
}
