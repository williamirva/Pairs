#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->findPushButton, &QPushButton::clicked, this,
            &MainWindow::findPushButton_clicked);

}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::findPushButton_clicked()
{
    std::string file_name = file_name_.toStdString();

    ifstream file_object(file_name);

    if (!file_object)
    {
        ui->textBrowser->setText("File not found");
        return;
    }
    else if (file_object and word_ == "")
    {
        ui->textBrowser->setText("File found");
        return;
    }
    else if (file_object and word_ != "")
    {
        string row;
        string word = word_.toStdString();

        if (ui->matchCheckBox->isChecked())
        {
            while (getline(file_object, row))
            {
                if (row.find(word) != string::npos)
                {
                    ui->textBrowser->setText("Word found");
                    return;
                }
            }
            ui->textBrowser->setText("Word not found");
            return;
        }
        else
        {
                while (getline(file_object, row))
                {
                    for_each(row.begin(),row.end(), [] (char & c)
                        {
                          c = ::tolower(c);
                        });
                    for_each(word.begin(), word.end(), [] (char & c)
                        {
                            c = ::tolower(c);
                        });
                    if (row.find(word) != string::npos)
                    {
                        ui->textBrowser->setText("Word found");
                        return;
                    }
                }

                    ui->textBrowser->setText("Word not found");
                    return;
        }
    }

    file_object.close();
}

void MainWindow::on_fileLineEdit_editingFinished()
{
    file_name_ = ui->fileLineEdit->text();
}

void MainWindow::on_keyLineEdit_editingFinished()
{
    word_ = ui->keyLineEdit->text();
}
