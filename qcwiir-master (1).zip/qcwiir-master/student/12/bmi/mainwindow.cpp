#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->countButton, &QPushButton::clicked, this,
            &MainWindow::countButton_clicked);
    connect(ui->closeButton, &QPushButton::clicked, this,
            &MainWindow::closeButton_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_weightLineEdit_editingFinished()
{
    weight_ = ui->weightLineEdit->text();
}

void MainWindow::on_heightLineEdit_textChanged(const QString &height_input)
{
    height_ = height_input;
}

void MainWindow::countButton_clicked()
{
    double double_weight = weight_.toDouble();
    double double_height = height_.toDouble();
    double height_m = double_height / 100;


    double result = double_weight / (height_m * height_m);
    QString str_result = QString::number(result);
    ui->resultLabel->setText(str_result);

    if (result > 25)
    {
        ui->infoTextBrowser->setText("You are overweight.");
    }
    else if (result < 18.5)
    {
        ui->infoTextBrowser->setText("You are underweight.");
    }
    else
    {
        ui->infoTextBrowser->setText("Your weight is normal.");
    }
}

void MainWindow::closeButton_clicked()
{
    close();
}
