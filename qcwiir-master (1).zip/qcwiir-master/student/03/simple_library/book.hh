#ifndef BOOK_HH
#define BOOK_HH
#include "date.hh"

#include<string>

class Book
{
public:
    // constructor
    Book(const std::string& author, const std::string name );

    // more methods

    void print() const;
    bool loaned = false;
    void loan(const Date& D);
    void renew();
    void give_back();


private:
    const std::string& author;
    const std::string name;
    Date loan_start;
    Date Loan_end;

};

#endif // BOOK_HH
