#include "book.hh"
#include "date.hh"

#include<iostream>

Book::Book(const std::string& author, const std::string name):
    author(author),
    name(name)

{

}
void Book::print() const
{
    std::cout << author << " : " << name << std::endl;
    if ( !loaned )
    {
        std::cout << "- available" << std::endl;
    }
    else
    {
        std::cout << "- " <<"loaned: ";
        loan_start.print();
        std::cout << "- " << "to be returned: ";
        Loan_end.print();
    }
}
void Book::loan(const Date& D)
{
    if ( loaned )
    {
        std::cout << "Already loaned: cannot be loaned" << std::endl;
    }
    else
    {
        loaned = true;
        loan_start = D;
        Loan_end = loan_start;
        Loan_end.advance(28);
    }
}

void Book::renew()
{
    if ( loaned )
    {
        Loan_end.advance(28);
    }
    else
    {
        std::cout << "Not loaned: cannot be renewed" << std::endl;
    }
}

void Book::give_back()
{
    loaned = false;
}
