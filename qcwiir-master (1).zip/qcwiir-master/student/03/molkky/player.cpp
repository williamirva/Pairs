#include "player.hh"

#include <iostream>
#include <string>

Player::Player(const std::string& name):
    NAME_(name), points_(0)

{

}

const std::string& Player::get_name()
{
    return NAME_;
}

int Player::get_points()
{
    return points_;
}

bool Player::has_won()
{
    return points_ == 50;
}

void Player::add_points(int pts)
{
    points_ += pts;
    if (points_ > 50 )
    {
        std::cout << NAME_ << " gets penalty points!" << std::endl;
        points_ = 25;
    }
}
