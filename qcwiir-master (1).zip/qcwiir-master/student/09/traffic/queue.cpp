#include "queue.hh"
#include "iostream"



// Implement the member functions of Queue here

Queue::Queue(unsigned int cycle): cycle_(cycle)
{

}

Queue::~Queue()
{
    while (first_ != nullptr)
    {
        Vehicle* old_car = first_;
        first_ = first_->next;
        delete old_car;
    }
}

void Queue::enqueue(string reg)
{
    if (is_green_)
    {
        std::cout << "GREEN: The vehicle " << reg << " need not stop to wait" << std::endl;
        return;
    }
    Vehicle* vehicle = new Vehicle;
    vehicle->reg_num = reg;
    vehicle->next = nullptr;

    if (first_ == nullptr)
    {
        first_ = vehicle;
        last_ = vehicle;
    }
    else
    {
        last_->next = vehicle;
        last_ = vehicle;
    }
}

void Queue::switch_light()
{
    if (is_green_)
    {
        is_green_ = false;
        print();
        passed_cars = 0;
        return;
    }
    is_green_ = true;
    print();
}
void Queue::reset_cycle(unsigned int cycle)
{
    cycle_ = cycle;
}

void Queue::print()
{
    string light;
    Vehicle* current = first_;

    if (current == nullptr)
    {
        if (is_green_)
        {
            std::cout << "GREEN: No vehicles waiting in traffic lights" << std::endl;
            return;
        }
        std::cout << "RED: No vehicles waiting in traffic lights" << std::endl;
        return;
    }
    if (is_green_)
    {
        light = "GREEN";

        std::cout << light << ": " << "Vehicle(s) ";

        unsigned int reps = 0;


        while (current != nullptr)
        {
            std::cout << current->reg_num << " ";
            current = current->next;
            ++reps;
            if (reps == cycle_)
            {
                break;
            }
        }


        std::cout << "can go on" << std::endl;

        reps = 0;

        current = first_;


        while (current != nullptr)
        {
            dequeue();
            current = current->next;
            ++reps;
            ++passed_cars;
            if (passed_cars == cycle_)
            {
                is_green_ = false;
                passed_cars = 0;
                break;
            }
            if (reps == cycle_)
            {
                break;
            }
        }
        is_green_ = false;
}
    else
    {
        light = "RED";

        std::cout << light << ": " << "Vehicle(s) ";

        while (current != nullptr)
        {
            std::cout << current->reg_num << " ";
            current = current->next;
        }

        std::cout << "waiting in traffic lights" << std::endl;
    }
}

void Queue::dequeue()
{
    if (first_->next == nullptr)
    {
        first_ = nullptr;
        last_ = nullptr;
    }
    else
    {
        Vehicle* old_first = first_;
        first_ = first_->next;
        delete old_first;

    }
}
