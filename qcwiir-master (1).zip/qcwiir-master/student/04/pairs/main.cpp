/* Muistipeli
 *
 * Kuvaus:
 * Ohjelma toteuttaa perinteisen muistipelin, johon käyttäjä
 * voi syöttää haluamansa määrän kortteja ja pelaajia.
 * Annettujen tietojen perusteella ohjelma luo pelilaudan
 * Sekä nimetyt pelaajat. Pelaajalta myös kysytään siemenluku (seed)
 * korttien paikkojen arpomista varten.
 *
 * Alkutietojen kysymisen jälkeen siirrytään itse peliin, jossa tulostetaan
 * pelilauta kortteineen, sekä koordinaattiakselit, joiden perusteella pelaaja
 * syöttää koordinaattit käännettäville korteille. Jos koordinaatit eivät ole
 * oikeanlaisia tulostetaan virheilmoitus. Pelaajan on myös mahdollista
 * lopettaa peli komennolla "q".
 *
 * Korttien kääntämisen jälkeen tarkistetaan ovatko ne pareja.
 * Jos pari löytyy kortit lisätään pelaajalle, muutoin vuoro siirtyy
 * seuraavalle pelaajalle.
 *
 * Kun kaikki korttipaikat ovat tyhjiä tulostetaan pelin voittaja tai
 * se, kuinka monen pelaajan välillä tuli tasapeli.
 *
 * Ohjelman kirjoitaja:
 * Nimi: Antti-William Irva
 * Opiskelijanumero: 050087565
 * Kayttajatunnus: qcwiir ( Git-repositorion hakemistonimi. )
 * E-Mail: william.irva@tuni.fi
 *
 * Huomioita ohjelmasta ja sen toteutuksesta:
 *
 * Varsinainen peli tapahtuu void funktiossa "game".
 * Tälle on puolestaan luotu erilaisia apufunktioita.
 * mainissa tehdään ainoastaan pelin alustus ja pelin
 * vaatimat alkutiedot, sekä ohjelman toiminnan päättäminen.
 *
 * */
#include <player.hh>
#include <card.hh>
#include <iostream>
#include <vector>
#include <random>


using namespace std;

const string INPUT_AMOUNT_OF_CARDS = "Enter the amount of cards (an even number): ";
const string INPUT_SEED = "Enter a seed value: ";
const string INPUT_AMOUNT_OF_PLAYERS = "Enter the amount of players (one or more): ";
const string INPUT_CARDS = "Enter two cards (x1, y1, x2, y2), or q to quit: ";
const string INVALID_CARD = "Invalid card.";
const string FOUND = "Pairs found.";
const string NOT_FOUND = "Pairs not found.";
const string GIVING_UP = "Why on earth you are giving up the game?";
const string GAME_OVER = "Game over!";

using Game_row_type = vector<Card>;
using Game_board_type = vector<vector<Card>>;

// Muuntaa annetun numeerisen merkkijonon vastaavaksi kokonaisluvuksi
// (kutsumalla stoi-funktiota).
// Jos annettu merkkijono ei ole numeerinen, palauttaa nollan
// (mikä johtaa laittomaan korttiin myöhemmin).
//
// Converts the given numeric string to the corresponding integer
// (by calling stoi).
// If the given string is not numeric, returns 0
// (which leads to an invalid card later).
unsigned int stoi_with_check(const string& str)
{
    bool is_numeric = true;
    for(unsigned int i = 0; i < str.length(); ++i)
    {
        if(not isdigit(str.at(i)))
        {
            is_numeric = false;
            break;
        }
    }
    if(is_numeric)
    {
        return stoi(str);
    }
    else
    {
        return 0;
    }
}

// Täyttää pelilaudan (kooltaan rows * columns) tyhjillä korteilla.
//
// Fills the game board, the size of which is rows * columns, with empty cards.
void init_with_empties(Game_board_type& g_board, unsigned int rows, unsigned int columns)
{
    g_board.clear();
    Game_row_type row;
    for(unsigned int i = 0; i < columns; ++i)
    {
        Card card;
        row.push_back(card);
    }
    for(unsigned int i = 0; i < rows; ++i)
    {
        g_board.push_back(row);
    }
}

// Etsii seuraavan tyhjän kohdan pelilaudalta (g_board) aloittamalla
// annetusta kohdasta start ja jatkamalla tarvittaessa alusta.
// (Kutsutaan vain funktiosta init_with_cards.)
//
// Finds the next free position in the game board (g_board), starting from the
// given position start and continuing from the beginning if needed.
// (Called only by the function init_with_cards.)
unsigned int next_free(Game_board_type& g_board, unsigned int start)
{
    // Selvitetään annetun pelilaudan rivien ja sarakkeiden määrät
    //
    // Finding out the number of rows and columns of the game board
    unsigned int rows = g_board.size();
    unsigned int columns = g_board.at(0).size();

    // Aloitetaan annetusta arvosta
    //
    // Starting from the given value
    for(unsigned int i = start; i < rows * columns; ++i)
    {
        if(g_board.at(i / columns).at(i % columns).get_visibility() == EMPTY) // vaihdettu
        {
            return i;
        }
    }
    // Jatketaan alusta
    //
    // Continuing from the beginning
    for(unsigned int i = 0; i < start; ++i)
    {
        if(g_board.at(i / columns).at(i % columns).get_visibility() == EMPTY)
        {
            return i;
        }
    }
    // Tänne ei pitäisi koskaan päätyä
    //
    // You should never reach this
    std::cout << "No more empty spaces" << std::endl;
    return rows * columns - 1;
}

// Alustaa annetun pelilaudan (g_board) satunnaisesti arvotuilla korteilla
// annetun siemenarvon (seed) perusteella.
//
// Initializes the given game board (g_board) with randomly generated cards,
// based on the given seed value.
void init_with_cards(Game_board_type& g_board, int seed)
{
    // Selvitetään annetun pelilaudan rivien ja sarakkeiden määrät
    //
    // Finding out the number of rows and columns of the game board
    unsigned int rows = g_board.size();
    unsigned int columns = g_board.at(0).size();

    // Arvotaan täytettävä sijainti
    //
    // Drawing a cell to be filled
    std::default_random_engine randomEng(seed);
    std::uniform_int_distribution<int> distr(0, rows * columns - 1);
    // Hylätään ensimmäinen satunnaisluku (joka on aina jakauman alaraja)
    //
    // Wiping out the first random number (that is always the lower bound of the distribution)
    distr(randomEng);

    // Jos arvotussa sijainnissa on jo kortti, valitaan siitä seuraava tyhjä paikka.
    // (Seuraava tyhjä paikka haetaan kierteisesti funktion next_free avulla.)
    //
    // If the drawn cell is already filled with a card, next empty cell will be used.
    // (The next empty cell is searched for circularly, see function next_free.)
    for(unsigned int i = 0, c = 'A'; i < rows * columns - 1; i += 2, ++c)
    {
        // Lisätään kaksi samaa korttia (parit) pelilaudalle
        //
        // Adding two identical cards (pairs) in the game board
        for(unsigned int j = 0; j < 2; ++j)
        {
            unsigned int cell = distr(randomEng);
            cell = next_free(g_board, cell);
            g_board.at(cell / columns).at(cell % columns).set_letter(c);
            g_board.at(cell / columns).at(cell % columns).set_visibility(HIDDEN);
        }
    }
}

// Tulostaa annetusta merkistä c koostuvan rivin,
// jonka pituus annetaan parametrissa line_length.
// (Kutsutaan vain funktiosta print.)
//
// Prints a line consisting of the given character c.
// The length of the line is given in the parameter line_length.
// (Called only by the function print.)
void print_line_with_char(char c, unsigned int line_length)
{
    for(unsigned int i = 0; i < line_length * 2 + 7; ++i)
    {
        cout << c;
    }
    cout << endl;
}

// Tulostaa vaihtelevankokoisen pelilaudan reunuksineen.
//
// Prints a variable-length game board with borders.
void print(const Game_board_type& g_board)
{
    // Selvitetään annetun pelilaudan rivien ja sarakkeiden määrät
    //
    // Finding out the number of rows and columns of the game board
    unsigned int rows = g_board.size();
    unsigned int columns = g_board.at(0).size();

    print_line_with_char('=', columns);
    cout << "|   | ";
    for(unsigned int i = 0; i < columns; ++i)
    {
        cout << i + 1 << " ";
    }
    cout << "|" << endl;
    print_line_with_char('-', columns);
    for(unsigned int i = 0; i < rows; ++i)
    {
        cout << "| " << i + 1 << " | ";
        for(unsigned int j = 0; j < columns; ++j)
        {
            g_board.at(i).at(j).print();
            cout << " ";
        }
        cout << "|" << endl;
    }
    print_line_with_char('=', columns);
}

// Kysyy käyttäjältä tulon ja sellaiset tulon tekijät, jotka ovat
// mahdollisimman lähellä toisiaan.
//
// Asks the desired product from the user, and calculates the factors of
// the product such that the factor as near to each other as possible.
void ask_product_and_calculate_factors(unsigned int& smaller_factor, unsigned int& bigger_factor)
{
    unsigned int product = 0;
    while(not (product > 0 and product % 2 == 0))
    {
        std::cout << INPUT_AMOUNT_OF_CARDS;
        string product_str = "";
        std::getline(std::cin, product_str);
        product = stoi_with_check(product_str);
    }

    for(unsigned int i = 1; i * i <= product; ++i)
    {
        if(product % i == 0)
        {
            smaller_factor = i;
        }
    }
    bigger_factor = product / smaller_factor;
}

// Kysyy käyttäjältä pelaajien määrän ja nimet, jonka jälkeen
// luo niistä pelaajaoliot ja tallentaa niiden osoittimet vektoriin.
vector<Player> ask_amount_of_players_and_create_them()
{
    // Kysytään pelaajien määrä ja tarkistetaan, että syöte on
    // kokonaisluku ja suurempi kuin yksi.
    int amount_of_players = 0;
    while (amount_of_players < 1)
        {
        std::cout << INPUT_AMOUNT_OF_PLAYERS;
        string amount_str = "";
        std::getline(std::cin, amount_str);
        amount_of_players = stoi_with_check(amount_str);
        }

    // Alustetaan vektorit pelaajien nimille ja oliolle, jonka jälkeen
    // kysytään pelaajien määrän verran nimiä, talletetaan ne vektoriin,
    // ja lopuksi nimivektroin avulla luodaan vastaavat oliot ja talle-
    // tetaan ne omaan vektoriinsa, joka on myös funktion paluuarvo.
    std::vector<string> names;
    std::vector<Player> players;
    string name;
    std::cout << "List " << amount_of_players << " players: ";
    for (int i=0; i<amount_of_players; i++)
        {
            cin >> name;
            names.push_back(name);
        }

    for (int i=0; i<amount_of_players; i++)
        {
            players.push_back(Player(names[i]));
        }

    return players;

}

// tarkistaa onko peli päättynyt vertaamalla löydettyjen
// korttien määrää korttipaikkojen määrään.
bool game_over(vector<Player> players, Game_board_type g_board)
{
    int found_pairs = 0;
    int rows = g_board.size();
    int columns = g_board.at(0).size();
    for (Player player : players)
        {
            found_pairs += player.number_of_pairs();
        }
    found_pairs*=2;

    if ( found_pairs >= (rows*columns))
        {
             return true;
        }
    else
    {
        return false;
    }

}
// funktio koordinaattien kysymiselle. Palauttaa string
//  vektorin syötetyistä koordinaateista.
vector<string> ask_coordinates(Player player_i_t)
{
    vector<string> coordinates;
    string coordinate;
    cout << player_i_t.get_name()<< ": " << INPUT_CARDS;
    for (int i=0; i<4; i++)
        {
        cin >> coordinate;
        if (coordinate == "q")
            {
                coordinates.push_back(coordinate);
                return coordinates;
            }
            else
            {
            coordinates.push_back(coordinate);
            }
        }
    return coordinates;
}

// luo koordinaateista kokonaisluvut ja
// tallettaa ne kokonaislukuvektoriin
vector<int> create_integers(vector<string> coordinates)
{
    vector<int> int_coordinates;
    int x1 = stoi_with_check(coordinates[0]);
    int y1 = stoi_with_check(coordinates[1]);
    int x2 = stoi_with_check(coordinates[2]);
    int y2 = stoi_with_check(coordinates[3]);
    int_coordinates.push_back(x1);
    int_coordinates.push_back(y1);
    int_coordinates.push_back(x2);
    int_coordinates.push_back(y2);

    return int_coordinates;
}

// Tarkastaa onko käyttäjä syöttänyt lopetus komentoa
// Parametrinä pelaajan antamat koordinaatit
bool is_quit_command(vector<string> coordinates)
{

    if (coordinates[0] == "q")
        {
            return true;
        }
    else
        {
        return false;
        }

}

// Tarkastaa ovatko koordinaatit kokonaislukuja
// Parametrinä pelaajan antamat koordinaatit
bool not_integers(vector<string> coordinates)
{
    for ( string coordinate : coordinates )
    {
        if (stoi_with_check(coordinate) == 0)
        {
            return true;
        }
        else
        {
            continue;
        }
    }
    return false;
}

// Tarkistaa ovatko koordinaatit samoja
// Parametrinä pelaajan antamat koordinaatit
bool same_coordinates(vector<string> coordinates)
{
    int x1 = stoi_with_check(coordinates[1]);
    int y1 = stoi_with_check(coordinates[0]);
    int x2 = stoi_with_check(coordinates[3]);
    int y2 = stoi_with_check(coordinates[2]);

    if (x1 == x2 and y1 == y2)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Tarkistaa ovatko koordinaatit pelilaudalla
// hyödyntäen pelilaudan rivejä ja sarakkeita
// Parametreinä pelaajan korrdinaatit ja pelilauta
bool not_on_board(vector<string> coordinates, Game_board_type g_board)
{
    int rows = g_board.size();
    int columns = g_board.at(0).size();
    int x1 = stoi_with_check(coordinates[1]);
    int y1 = stoi_with_check(coordinates[0]);
    int x2 = stoi_with_check(coordinates[3]);
    int y2 = stoi_with_check(coordinates[2]);
    if (x1 > rows or x2 > rows)
    {
        return true;
    }
    else if (y1 > columns or y2 > columns)
    {
        return true;
    }
    else
    {
        return false;
    }

}

// tarkistaa onko käännettävistä korteista kumpikaan tyhjiä.
// Parametreinä pelaajan koordinaatit ja pelilauta.
bool empty(vector<int> int_coordinates, Game_board_type game_board)
{
    if (game_board.at(int_coordinates[1]-1).at(int_coordinates[0]-1).get_visibility() == EMPTY)
    {
        return true;
    }
    else if (game_board.at(int_coordinates[3]-1).at(int_coordinates[2]-1).get_visibility() == EMPTY)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Palauttaa totuusarvon tiedon, löytyikö paria.
// parametrinä pelaajan syöttämiä koordinaatteja vastaavat kortit
bool is_pair_found(Card& card1, Card& card2)
{
    if (card1.get_letter() == card2.get_letter())
    {
        return true;
    }
    else
    {
        return false;
    }
}

// tulostaa pistetilanteen vuoron lopuksi player luokan print-metodin avulla.
void live_result(vector<Player> players)
{
    for (Player player : players) 
        player.print();
}

// Selvittää kuka/ kuinka moni keräsi eniten pareja ja
// tulostaa pelin lopputuloksen
void final_results(vector<Player> players)
{
    int tied = 0;
    int n = players.size();
    Player &winner = players[0];
    for (int i=0; i<n; i++) // vertailee pelaajien pistemääriä ja asetta voittajaksi eniten pareja löytäneen.
    {
        Player player_to_compare = players[i];
        if (player_to_compare.number_of_pairs() > winner.number_of_pairs())
        {
            Player winner = player_to_compare;
        }
    }
    for (Player player : players) // Käy vielä läpi onko kellään voittajan kanssa yhtä paljon pareja.
    {
        if (winner.number_of_pairs() == player.number_of_pairs())
        {
            tied += 1;
        }
    }
    if (tied > 1)
    {
        cout << "Tie of " << tied << " players " << "with " << winner.number_of_pairs() << " pairs." << endl;
    }
    else
    {
        cout << winner.get_name() << " has won with " << winner.number_of_pairs() << " pairs." << endl;
    }
}
// Varsinaisen pelin toteuttava funktio.
// Ottaa parametreinä pelilaudan ja pelaajaoliot vektorina
void game(std::vector<Player> players, Game_board_type game_board)
{
    int turn_index = 0;
    int num_of_players = players.size();
    bool winner_not_found = true; // Totuusarvo joka pitää pelin käynnissä
    while (winner_not_found)
    {

        Player& in_turn = players[turn_index];
        print(game_board);
        bool players_turn = true;
        while (players_turn) // loop joka jatkuu pelaajan vuoron ajan
            {
                // kysytään koordinaatit vuorossa olevalta pelaajalta.
                vector<string> coordinates = ask_coordinates(in_turn);
                // Alla järjestyksessä bool funktioita, jotka tarkistavat
                // nimensä mukaiset asiat.
                if (is_quit_command(coordinates))
                {
                    cout << GIVING_UP << endl;
                    return;
                }
                else if (not_integers(coordinates))
                {
                    cout << INVALID_CARD << endl;
                }
                else if (same_coordinates(coordinates))
                {
                    cout << INVALID_CARD << endl;
                }
                else if (not_on_board(coordinates, game_board))
                {
                    cout << INVALID_CARD << endl;
                }
                else
                {
                    vector<int> int_coordinates = create_integers(coordinates); // luodaan koordinaateista kokonaislukuvektori
                    if(empty(int_coordinates, game_board))
                    {
                        cout << INVALID_CARD << endl;
                    }
                    // Jos syöte ei ole "q" tai virheellinen, nimetään korttioliot ja
                    // käännetään ne.
                    else
                    {
                        Card& card1 = game_board.at(int_coordinates[1]-1).at(int_coordinates[0]-1);
                        Card& card2 = game_board.at(int_coordinates[3]-1).at(int_coordinates[2]-1);
                        card1.turn();
                        card2.turn();
                        print(game_board);
                        // Tarkistetaan  löytyikö pareja. Jos löytyy, lisätään kortit
                        // pelaajalle ja merkitään korttien paikat tyhjiksi.
                        // Samalla tarkistetaan päättyikö peli vai kysytäänkö pelaajalta
                        // uudet koordinaatit.
                        if(is_pair_found(card1, card2))
                        {
                            cout << FOUND << endl;
                            in_turn.add_card(card1, card2);
                            card1.set_invisibility();
                            card2.set_invisibility();
                            live_result(players);
                            print(game_board);
                            // tarkistaa onko peli päättynyt. Jos pelipäättyy
                            // tulostetaan lopputulokset ja päätetään pelin silmukka.
                            if (game_over(players, game_board))
                                {
                                    cout << GAME_OVER << endl;
                                    final_results(players);
                                    winner_not_found = false;
                                    break;
                                }
                            else
                                {
                                    continue;
                                }
                        }
                        // Jos kortit eivät olleet pari siirretään vuoro seuraavalle pelaajalle ja
                        // päätetään nykyinen vuoro.
                        else
                        {
                            cout << NOT_FOUND << endl;
                            card1.turn();
                            card2.turn();
                            live_result(players);
                            if (turn_index+1 >= num_of_players)
                            {
                                turn_index=0;
                            }
                            else
                            {
                                turn_index+=1;
                            }
                            players_turn = false;
                        }
                    }
                }
            }
        }

}

int main()
{
    Game_board_type game_board;

    unsigned int factor1 = 1;
    unsigned int factor2 = 1;
    ask_product_and_calculate_factors(factor1, factor2);
    init_with_empties(game_board, factor1, factor2);

    string seed_str = "";
    std::cout << INPUT_SEED;
    std::getline(std::cin, seed_str);
    int seed = stoi_with_check(seed_str);
    init_with_cards(game_board, seed);
    vector<Player> players = ask_amount_of_players_and_create_them();
    game(players, game_board);


    return EXIT_SUCCESS;
}

