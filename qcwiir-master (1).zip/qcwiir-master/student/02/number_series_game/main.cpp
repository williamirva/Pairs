#include <iostream>

using namespace std;
int main()
{
    int lukumaara = 0;
    std::cout << "How many numbers would you like to have? ";
    cin >> lukumaara;
    for ( int luku = 1; luku < lukumaara+1; ++luku)
    {
        if ( luku % 7 == 0 and luku % 3 == 0 )
        {
            cout << "zip boing" << endl;
        } else if ( luku % 3 == 0 )
        {
            cout << "zip" << endl;
        } else if (luku % 7 == 0)
        {
            cout << "boing" << endl;
        } else
        {
            cout << luku << endl;
        }
    }
}
