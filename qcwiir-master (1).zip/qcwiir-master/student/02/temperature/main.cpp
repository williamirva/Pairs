#include <iostream>

using namespace std;

int main()
{
    int temperature = 0;
    cout << "Enter a temperature: ";
    cin >> temperature;
    double temp_in_F = temperature * 1.8 + 32;
    double temp_in_C = ( temperature - 32 ) / 1.8;
    cout << temperature << " degrees Celsius is " << temp_in_F << " degrees Fahrenheit " << endl;
    cout << temperature << " degrees Fahrenheit is " << temp_in_C << " degrees Celsius " << endl;
    return 0;
}
