#include <iostream>
#include <cctype>

using namespace std;

bool key_length(string key)
{
    if ( key.length() != 26 )
    {
        cout << "Error! The encryption key must contain 26 characters." << endl;
        return false;
    }
    else
    {
        return true;
    }
}
bool key_lcase_check(string key)
{
    char letter;
    for ( int i = 0; i < 26; i++ )
    {
        letter = key.at(i);
        bool b = islower(letter);
        if ( b != true )
        {
            cout << "Error! The encryption key must contain only lower case characters." << endl;
            return false;
        }
        else
        {
            continue;
        }
    }
    return true;
}
bool key_alphabet_check(string key)
{
    string::size_type place = 0;
    for ( char i = 'a'; i <= 'z'; i++ )
    {
        place = key.find(i);
        if ( place == string::npos )
        {
            cout << "Error! The encryption key must contain all alphabets a-z." << endl;
            return false;
        }
            else
            {
                continue;
            }
    }
    return true;
}
void encrypt(string key, string text )
{
   std::cout << "Encrypted text: ";
   for (std::string::size_type i = 0; i < text.length(); ++i )
   {
       char plain = text[i];
       std::string::size_type key_index = plain -'a';
       char encrypted = key[key_index];
       std::cout << encrypted;
   }
   std::cout << endl;
}

int main()
{
    std::string key = "";
    std::cout << "Enter the encryption key: ";
    std::cin >> key;
    if ( key_length(key) == false )
    {
        return EXIT_FAILURE;
    }
    else if( key_lcase_check(key) == false )
    {
        return EXIT_FAILURE;
    }
    else if ( key_alphabet_check(key) == false )
    {
        return EXIT_FAILURE;
    }

    else
    {

    std::string text = "";
    std::cout << "Enter the text to be encrypted: ";
    std::cin >> text;
    encrypt(key,text);
    }

    return EXIT_SUCCESS;
}
