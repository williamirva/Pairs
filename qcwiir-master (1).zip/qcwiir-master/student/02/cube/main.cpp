#include <iostream>

using namespace std;

int main()
{
    int n = -1;
    cout << "Enter a number: ";
    cin >> n;
    if ( n == 0 )
    {
    cout << "The cube of " << n << " is " << n << "." << endl;
    return 0;
    }
        int cubic = n * n * n;
        int check = ( cubic / n ) / n;
        if ( n == 0 or n != check )
        {
            cout << "Error! The cube of " << n << " is not " << cubic << "." << endl;
        }
        else
        {
        cout << "The cube of " << n << " is " << cubic << "." << endl;
        }
        return 0;
}
