#include <iostream>

using namespace std;


    unsigned long int factorial( int n )
    {
    unsigned long int x = 1;
    if ( n > 0 )
    {
            for (int i = 1; i <= n; ++i )
            {
             x = i * x;
            }
            return x;
    }
    else
        {
            return 1;
        }
    }
    void lotto(int total, int drawn )
    {
        unsigned long int fact_total = factorial( total );
        unsigned long int fact_drawn = factorial( drawn );
        unsigned long int t_d = (total - drawn );
        unsigned long int fact_t_d = factorial( t_d );
        unsigned long int combinations = (fact_total) / (fact_t_d*fact_drawn);

        if ( total <= 0 )
        {
            cout << "The number of balls must be a positive number." << endl;
        }
        else if ( total < drawn )
        {
            cout << "The maximum number of drawn balls is the total amount of balls." << endl;
        }
        else
        {
            cout << "The probability of guessing all " << drawn << " balls correctly is " << "1/" << combinations << endl;
        }
    }


int main()
{
    int total = 0;
    cout << "Enter the total number of lottery balls: ";
    cin >> total;
    int drawn = 0;
    cout << "Enter the number of drawn balls: ";
    cin >> drawn;

    lotto(total, drawn);
    return EXIT_SUCCESS;
}
