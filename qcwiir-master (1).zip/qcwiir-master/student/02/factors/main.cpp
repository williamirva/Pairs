#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n = 0;
    cout << "Enter a positive number: ";
    std::cin >> n;

    if ( n <= 0 )
    {
        cout << "Only positive numbers accepted" << endl;
    }
    else
    {

        int factor_cand = std::max(static_cast<int>(sqrt(n)), 1);
        for (; n % factor_cand != 0; -- factor_cand );

        int factor1 = factor_cand;
        int factor2 = n / factor_cand;

        cout << n << " = " << factor1 << " * " << factor2 << endl;
    }


    return 0;
}
