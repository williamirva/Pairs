/* Rasse 2
 *
 * Kuvaus:
 * Ohjelma lukee tiedostosta ratikkalinjojen tiedot, jonka jalkeen
 * kaynnistaa kayttaliittyman. Kayttaja voi nyt eri komennoilla etsia tietoa ja lisata tietoa
 * ratikkalinjoihin.
 *
 * Komennot:
 *
 * HUOM! Komennot oltava tarkalleen tassa esitetyssa muodossa jotta ohjelma toimii.
 *
 * QUIT - Lopettaa ohjelman suorituksen.
 * LINES - Tulostaa linjat aakkosjarjestyksessa allekkain.
 * LINE <linja> - Tulostaa syotetyn linjan pysakit reitin mukaisessa jarjestyksessa allekkain.
 * STOPS - Tulostaa kaikki pysakit kaikilta linjoilta aakkosjarjestyksessa allekkain.
 * STOP <pysakki> - Tulostaa allekkain ne linjat joille syotetty pysakki kuuluu.
 * DISTANCE <linja> <pysakki1> <pysakki2> - Tulostaa syotettyjen pysakkien etaisyyden toisistaan
 * syotetylla linjalla.
 * ADDLINE <linja> - Lisaa pysakittoman linjan.
 * ADDSTOP <linja> <uusi pysakki> <etaisyys> - Lisaa syotetylle linjalle uuden pysakin ja
 * etaisyyden.
 * REMOVE <pysakki> - Poistaa syotetyn pysakin kaikilta linjoilta.
 *
 * Jos linjan tai pysakin nimessa esiintyy valilyonteja, nimi taytyy rajata hipsuin("").
 *
 * Ohjelman kirjoittajat
 * Nimi: Petteri Mönkkönen
 * Opiskelijanumero: H291010
 * Käyttäjätunnus: nkpemo
 * E-Mail: petteri.monkkonen@tuni.fi
 *
 * Nimi: William Irva
 * Opiskelijanumero: 50087565
 * Käyttäjätunnus: qcwiir
 * E-Mail: william.irva@tuni.fi
 * */

#include <iostream>
#include <map>
#include <vector>
#include <fstream>
#include <set>
#include <cctype>

using namespace std;
using Lines = map<string, map<string, double>>;

// The most magnificent function in this whole program.
// Prints a RASSE
void print_rasse()
{
    std::cout <<
                 "=====//==================//===\n"
                 "  __<<__________________<<__   \n"
                 " | ____ ____ ____ ____ ____ |  \n"
                 " | |  | |  | |  | |  | |  | |  \n"
                 " |_|__|_|__|_|__|_|__|_|__|_|  \n"
                 ".|                  RASSE   |. \n"
                 ":|__________________________|: \n"
                 "___(o)(o)___(o)(o)___(o)(o)____\n"
                 "-------------------------------" << std::endl;
}

// Funktio joka jakaa tekstisyötteen osiin halutun välimerkin kohdalta.
// Palauttaa pilkotut osat vektorina.
vector<std::string> split(const string& s, const char delimiter, bool ignore_empty = false)
{
    vector<string> result;
    string tmp = s;

    while(tmp.find(delimiter) != string::npos)
    {
        string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        if(not (ignore_empty and new_part.empty()))
        {
            result.push_back(new_part);
        }
    }
    if(not (ignore_empty and tmp.empty()))
    {
        result.push_back(tmp);
    }
    return result;
}

// Palauttaa totuusarvona false, jos tarkistettavaa linjaa ei ole,
// true puolestaan, jos linja on jo olemassa.
// param: &tram_lines: Tietorakenne, jossa linjat ja pysäkit ovat.
// param: line_name: tarkistettavan linjan nimi
bool IsAlreadyLine(Lines &tram_lines, string line_name)
{
    if (tram_lines.count(line_name) == 0)
    {
        return false;
    }
    return true;
}

// Vastaava tarkistusfunktio pysäkeille. Tarkistaa nimen lisäksi myös onko linjalla
// jo olemassa oleva pysäkki samalla etäisyydellä lähtöpysäkistä
// param:&tram_lines: Tietorakenne, jossa linjat ja pysäkit ovat.
// param: line_name: linja jolla tarkistettava pysäkki sijaitsee
// param: stop_name: tarkistettava pysäkki
// param: str_distance: tarkistettavan pysäkin etäisyys stringinä.
bool IsAlreadyStop(Lines &tram_lines, string line_name, string stop_name, string str_distance)
{
    double distance = stod(str_distance);
    if (tram_lines[line_name].count(stop_name) != 0)
        return true;
    else
    {
        for (auto stop_info : tram_lines[line_name])
        {
            if (distance == stop_info.second)
            {
                return true;
            }
        }
    }
    return false;
}

// Lukee tiedoston rivi kerrallaan ja tallentaa tiedostosta linjojen nimet
// tram_lines mapin avaimiksi ja niille paylodiksi toinen map, josssa taas
// avaimina pysäkkien nimet ja payloadina pysäkin etäisyys lähtöpysäkistä.
// Jos rivin lukemisessa törmätään ongelmaan, tulostetaan virhettä vastaava
// virheilmoitus.
// param: file name: luettavan tiedoston nimi.
// param: :&tram_lines: Tietorakenne, jossa linjat ja pysäkit ovat.
// return: bool: Palauttaa false, jos tiedostoa ei voida avata, tai jos
// syötetty tiedosto ei ole oikeanlaisessa muodossa. Jos tiedosto kelpaa
// lisätään tiedot tietorakenteeseen ja palautetaan true.
bool read_file(string file_name, Lines &tram_lines)
{
    ifstream file_object(file_name);
    if ( not file_object)
    {
        cout << "Error: File could not be read." << endl;
        return false;
    }
    else
        {
            string row;
            while (getline(file_object, row) )
            {
                vector<string> row_info = split(row, ';', true);
                if(1 < row_info.size() and row_info.size() < 4)
                {
                    string line_name = row_info[0];
                    string stop_name = row_info[1];
                    if (row_info.size()==2)
                    {
                        row_info.push_back("0");
                    }
                    string distance = row_info[2];

                        if (!IsAlreadyLine(tram_lines, line_name))
                        {
                            tram_lines[line_name] = {};
                            double num_distance = stod(distance);
                            tram_lines[line_name].insert({stop_name, num_distance});
                        }
                        else if (IsAlreadyLine(tram_lines, line_name))
                        {
                            if (!IsAlreadyStop(tram_lines, line_name, stop_name, distance))
                            {
                                double num_distance = stod(distance);
                                tram_lines[line_name].insert({stop_name, num_distance});
                            }
                            else
                            {
                                cout << "Error: Stop/line already exists." << endl;
                                file_object.close();
                                return false;
                            }
                        }
                 }
                 else
                {
                    cout << "Error: Invalid format in file." << endl;
                    file_object.close();
                    return false;
                }
             }
        }
    file_object.close();
    return true;

}
// Lisää linjan tram_lines mappiin. Käyttää IsAlreadyLine funktiota
// tarkistamaan, onko lisättävää linjaa vielä olemassa. Onnistuneen
// lisäyksen jälkeen tulostetaan viesti "Line was added".
// param:& tram_lines: tietorakenne johon linja lisätään.
// param: line_name: lisättävän linjan nimi
void addline(Lines &tram_lines, string line_name)
{
    if (IsAlreadyLine(tram_lines, line_name))
    {
        cout << "Error: Stop/line already exists." << endl;
        return;
    }
    else
    tram_lines[line_name] = {};
    cout << "Line was added." << endl;

}

// Vastaava funktio pysäkin lisäämiselle. Linjan tarkistaminen on identtinen
// addline funktion kanssa. Pysäkin nimen ja sen etäisyyden lähtöpysäksitä
// tarkistaminen tapahtuu IsAlreadyStop funktiolla. Tulostetaan "Stop was added",
// jos pysäkin lisääminen onnistuu.
// param:& tram_lines: tietorakenne johon pysäkki lisätään.
// param: line_name: linja johon pysäkki lisätään
// param: stop_name: lisättävä pysäkki.
// param: distance: lisättävän pysäkin etäisyys stringinä.
void addstop(Lines &tram_lines, string line_name, string stop_name, string distance)
{
    if (!IsAlreadyLine(tram_lines, line_name))
    {
        cout << "Error: Line could not be found." << endl;
        return;
    }
    else if (IsAlreadyStop(tram_lines, line_name, stop_name, distance))
    {
        cout << "Error: Stop/line already exists." << endl;
        return;
    }
    double num_distance = stod(distance);
    tram_lines[line_name].insert({stop_name, num_distance});
    cout << "Stop was added." << endl;
}

// Tulostaa tram_lines mapin avaimet, toisinsanoen linjojen nimet.
// param: tram_lines: tietorakenne, jossa linjat sijaitsevat,
void lines(Lines &tram_lines)
{
    for (auto pair : tram_lines)
    {
        cout << pair.first << endl;
    }
}

// Käy läpi annetun linjan pysäkit ja etäisyydet ja
// luo uuden mapin, jossa avaimena etäisyydet ja payloadina
// pysäkin nimi. Näin saadaan tulostettua linjan pysäkit
// etäisyyden lähtöpysäkistä mukaisessa järjestyksessä.
// param: line: linja jonka tiedot halutaan
// param: tram_lines: tietorakenne, jossa linja sijaitsee
void line(string line, Lines &tram_lines)
{
    if ( !IsAlreadyLine(tram_lines, line))
    {
        cout << "Error: Line could not be found." << endl;
        return;
    }
    double distance;
    string stop_name;
    map<string, double> line_map = tram_lines[line];
    map<double, string> swapped_line_map;

    for (auto pair : line_map)
    {
        distance = pair.second;
        stop_name = pair.first;

        swapped_line_map.insert({distance, stop_name});
    }
    std::cout << "Line " << line <<
    " goes through these stops in the order they are listed:" << std::endl;

    for (auto pair : swapped_line_map)
    {
        cout << " - " << pair.second << " : " << pair.first << endl;
    }
}

// Tallentaa jokaisen linjan pysäkit settiin, josta ne on
// helppo tulostuu aakkosjärjestyksessä
// param: tram_lines: tietorakenne, jonka pysäkit halutaan tulostaa.
void stops(Lines &tram_lines)
{
    set<string> stops;
    for (auto pair : tram_lines)
    {
        auto line = pair.second;
        for (auto p : line)
        {
            stops.insert(p.first);
        }
    }

    for (string stop : stops)
    {
        cout << stop << endl;
    }
}
// Vertaa parametrina olevaa pysäkkiä, jokaisen linjan pysäkkeihin.
// Jos pysäkki on linjalla, linjan nimi lisätään settiin, josta lin-
// jat lopulta tulostetaan järjestyksessä.
// param: stop: pysäkki, jonka tiedot halutaan
// param: tram_lines: tietorakenne, jossa pysäkki sijaitsee.
void stop(string stop, Lines &tram_lines)
{
    for (auto pair : tram_lines)
    {
        auto line = pair.second;
        for (auto p : line)
        {
            if (stop == p.first)
            {
                set<string> lines_including_stop;
                for (auto pair : tram_lines)
                {
                    auto line = pair.second;
                    string line_name = pair.first;
                    for (auto p : line)
                    {
                        if (stop == p.first)
                            lines_including_stop.insert(line_name);
                    }
                }
                cout << "Stop " << stop << " can be found on the following lines:" << endl;
                for (string line : lines_including_stop)
                {
                    cout << " - " << line << endl;
                }
                return;
            }
        }
    }
    cout << "Error: Stop could not be found." << endl;

}

// Funktio, joka kertoo kahden samalla linjalla sijaitsevan pysäkin välisen etäisyyden.
// Etäisyys ilmoitetaan aina positiivisena. Jos pysäkkiä tai linjaa ei löydy
// tulostetaan virhe ilmoitus
// param: tram_lines: tietorakenne, jossa pysäkit sijaitsevat.
// param: line: lija, jolla pyusäkit sijaitsevat.
// param: stop_1, stop_2: pysäkit, joiden välinen etäisyys halutaan.
void distance(Lines &tram_lines, string line, string stop_1, string stop_2)
{
    if (!IsAlreadyLine(tram_lines, line))
    {
        cout << "Error: Line could not be found." << endl;
    }
    else if ((tram_lines[line].count(stop_1) == 0))
    {
        cout << "Error: Stop could not be found." << endl;
    }
    else if ((tram_lines[line].count(stop_2) == 0))
    {
        cout << "Error: Stop could not be found." << endl;
    }

    double stop_1_distance = tram_lines[line].at(stop_1);
    double stop_2_distance = tram_lines[line].at(stop_2);
    double distance_between_stops = stop_1_distance - stop_2_distance;

    if ( distance_between_stops < 0)
    {
        distance_between_stops *= -1;
        cout << "Distance between " << stop_1 << " and "
             << stop_2 << " is " << distance_between_stops
             << endl;
    }
    else
    {
        cout << "Distance between " << stop_1 << " and "
             << stop_2 << " is " << distance_between_stops
             << endl;
    }
}

// Poistaa parametrina olevan pysäkin, jos se on olemassa.
// param: tram_lines: tietorakenne, jossa pysäkki sijaitsee
// param: stop_name: poistettava pysäkki
void remove_stop(Lines &tram_lines, string stop_name)
{
    for (auto pair : tram_lines)
    {
        auto line = pair.second;
        for (auto p : line)
        {
            if (stop_name == p.first)
            {
                for (auto pair : tram_lines)
                    {
                        if ((tram_lines[pair.first]).count(stop_name) != 0)
                        {
                            (tram_lines[pair.first]).erase(stop_name);
                        }
                    }
                cout << "Stop was removed from all lines." << endl;
                return;
            }
        }
     }

    cout << "Error: Stop could not be found." << endl;
}

// Funktio, joka käsittelee käyttäjän syöttämän komennon.
// Komennosta erotellaan kaksiosaiset pysäkin nimet, sekä muu-
// tetaan haluttu komento pieniksi kirjaimiksi.
// param: command_vector: käyttäjän syöttämä komento  vektorina
// return: vector<string>: palauttaa vektroin, jossa on käyttäjän
// komento mainille tulkittavassa muodossa.
vector<string> create_command_vector(vector<string> command_vector)
{
    size_t index = 0;
    vector<string> new_command_vector;

    while (index < command_vector.size())
    {
        string command = command_vector.at(index);
        if (index == 0)
        {
            size_t index2 = 0;
            while (command.size() > index2)
            {
                command.at(index2) = tolower(command.at(index2));
                ++index2;
            }

        }

        if (command.at(0) == '"')
        {
            command = command.erase(command.find('"'), 1);
            string command2;
            string new_command = "";
            command2 = (command_vector.at(index+1));
            command2 = command2.erase(command2.find('"'), 1);
            new_command = new_command + command + " " + command2;
            new_command_vector.push_back(new_command);
            index += 2;
        }
        else
        {
            new_command_vector.push_back(command);
            ++index;
        }
    }
    return new_command_vector;
}

// main sisäktää käyttöliittymän ja tiedoston nimen vastaanottamisen käyttäjältä.
// ensin tarkistetaan onnistuiko tiedoston luku, jos ei päättyy suoritus EXIT_FAILUREEN.
// Jos tiedosto on kelvollinen käyttäjä voi syöttää kokmentoja. Jos komento on epäkelpo
// tästä annetaan ilmoitus. Käyttäjän syöttäessä "quit", ohjelman suoritus päättyy paluu-
// arvoon EXIT_SUCCESS.
int main()
{
    Lines tram_lines;
    print_rasse();
    std::cout << "Give a name for input file: ";
        std::string filename;
        std::getline(cin, filename);

        if (!read_file(filename, tram_lines))
        {
            return EXIT_FAILURE;
        }
        while (true)
        {
            std::string command;
            std::cout << "tramway> ";
            std::getline(std::cin, command);

            std::vector<std::string> command_vector = split(command, ' ');
            command_vector = create_command_vector(command_vector);



            if (command_vector[0] == "quit" or command_vector[0] == "QUIT")
            {
                break;
            }
            else if (command_vector[0] == "lines" or command_vector[0] == "LINES")
            {
                std::cout << "All tramlines in alphabetical order:" << std::endl;
                lines(tram_lines);
            }
            else if (command_vector[0] == "line" or command_vector[0] == "LINE")
            {
                if (command_vector.size() == 1)
                {
                    std::cout << "Error: Invalid input." << std::endl;
                }
                else
                {
                    line(command_vector[1], tram_lines);
                }
            }
            else if (command_vector[0] == "stops" or command_vector[0] == "STOPS")
            {
                std::cout << "All stops in alphabetical order:" << std::endl;
                stops(tram_lines);
            }
            else if (command_vector[0] == "stop" or command_vector[0] == "STOP")
            {
                string tram_stop;
                if (command_vector.size() > 2)
                {
                    tram_stop = command_vector[1] + " " + command_vector[2];

                    stop(tram_stop, tram_lines);
                }
                else if (command_vector.size() == 1)
                {
                    std::cout << "Error: Invalid input." << std::endl;
                    continue;
                }
                else
                {
                    stop(command_vector[1], tram_lines);
                }
            }
            else if (command_vector[0] == "distance" or command_vector[0] == "DISTANCE")
            {
                if (command_vector.size() < 4)
                {
                    std::cout << "Error: Invalid input." << std::endl;
                    continue;
                }

                distance(tram_lines, command_vector[1], command_vector[2], command_vector[3]);
            }
            else if (command_vector[0] == "addline" or command_vector[0] == "ADDLINE")
                    {
                        if (command_vector.size() < 2)
                        {
                            std::cout << "Error: Invalid input." << std::endl;
                            continue;
                        }
                        addline(tram_lines, command_vector[1]);
            }
            else if (command_vector[0] == "addstop" or command_vector[0] == "ADDSTOP")
            {
                if (command_vector.size() < 4)
                {
                    std::cout << "Error: Invalid input." << std::endl;
                    continue;
                }
                else if (command_vector.size() == 5)
                {
                    string new_stop = command_vector[2] + " " + command_vector[3];
                    addstop(tram_lines, command_vector[1], new_stop, command_vector[3]);
                }
                else
                {
                    addstop(tram_lines, command_vector[1], command_vector[2], command_vector[3]);
                }
            }
            else if (command_vector[0] == "remove" or command_vector[0] == "REMOVE")
            {
                if (command_vector.size() < 2)
                {
                    std::cout << "Error: Invalid input." << std::endl;
                    continue;
                }
                else if (command_vector.size() > 2)
                {
                    string tram_stop;
                    tram_stop = command_vector[1] + " " + command_vector[2];
                    remove_stop(tram_lines, tram_stop);
                }
                remove_stop(tram_lines, command_vector[1]);
            }
            else
            {
                cout << "Error: Invalid input." << endl;
                continue;
            }
    }
    return EXIT_SUCCESS;
}
