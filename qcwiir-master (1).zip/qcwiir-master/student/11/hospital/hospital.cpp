
#include "hospital.hh"
#include "utils.hh"
#include <iostream>
#include <set>

Hospital::Hospital()
{
}

Hospital::~Hospital()
{
    // Deallocating staff
    for( std::map<std::string, Person*>::iterator
         iter = staff_.begin();
         iter != staff_.end();
         ++iter )
    {
        delete iter->second;
    }

    // Vapautetaan potilaiden varaamat muistipaikat
    for ( std::map<std::string, Person*>::iterator
          iter = all_patients.begin();
          iter != all_patients.end();
          ++iter)
    {
        delete iter->second;
    }

    for (auto object : care_periods_)
    {
        delete object;
    }
}

void Hospital::recruit(Params params)
{
    std::string specialist_id = params.at(0);
    if( staff_.find(specialist_id) != staff_.end() )
    {
        std::cout << ALREADY_EXISTS << specialist_id << std::endl;
        return;
    }
    Person* new_specialist = new Person(specialist_id);
    staff_.insert({specialist_id, new_specialist});
    std::cout << STAFF_RECRUITED << std::endl;
}

// Lisää potilaan sairaalaan. Ottaa paramterinä potilaan nimen.
// Potilaalle luodaan Person olio, sekä hoitojakso olio. Lisäksi talletetaan
// tarvittavat tiedot hospital.hh:ssa määritellyihin tietorakenteisiin.
// Jos potilas on aiemmin ollut sairaalssa, luodaan vain uusi hoitojakso.
void Hospital::enter(Params params)
{
    string patient_name = params.at(0);

    if (current_patients_.find(patient_name) != current_patients_.end())
    {
        cout << ALREADY_EXISTS << patient_name << endl;
        return;
    }

    for (CarePeriod* period : care_periods_)
    {
        // Jos henkilön nimellä löytyy aiempi hoitojakso
        // luodaan ainoastaan uusi hoitojakso-olio
        if (period->patient_->get_id() == patient_name)
        {
            Date beginning_date = utils::today;
            current_patients_.insert({patient_name, period->patient_});
            CarePeriod* new_care_period = new CarePeriod(beginning_date, period->patient_);
            care_periods_.push_back(new_care_period);
            cout << PATIENT_ENTERED << endl;
            return;
        }
    }

    Person* new_person = new Person(patient_name);
    Date beginning_date = utils::today;
    current_patients_.insert({patient_name, new_person});
    CarePeriod* new_care_period = new CarePeriod(beginning_date, new_person);
    care_periods_.push_back(new_care_period);
    all_patients.insert({patient_name, new_person});
    cout << PATIENT_ENTERED << endl;
}

// Poistaa potilaan sairaalasta ja cuurent_patients_ -
// tietorakenteesta. Ottaa paramterinä potilaan nimen.
void Hospital::leave(Params params)
{
    string patient_name = params.at(0);
    if (current_patients_.find(patient_name) == current_patients_.end())
    {
        cout << CANT_FIND << patient_name << endl;
        return;
    }
    for (CarePeriod* period : care_periods_)
    {
        if ( period->patient_->get_id() == patient_name and !period->care_period_ended)
        {
            period->set_ending_date(utils::today);
            current_patients_.erase(patient_name);
            period->care_period_ended = true;
            cout << PATIENT_LEFT << endl;
            return;
        }
    }


}

// Asettaa henkilökunnan jäsenen työskentelemään, syötetyn
// potilaan hoitojaksolle. virheilmoitus ainoastaan, jos
// potilasta tai henkilökunnan jäsentä ei löydy.
void Hospital::assign_staff(Params params)
{
    string staff_member_name = params.at(0);
    string patient_name = params.at(1);
    if (staff_.find(staff_member_name) == staff_.end())
    {
        cout << CANT_FIND << staff_member_name << endl;
        return;
    }
        else if (current_patients_.find(patient_name) == current_patients_.end())
        {
            cout << CANT_FIND << patient_name << endl;
            return;
        }
    for (CarePeriod* period : care_periods_)
    {
        // Etsitäää potilaan nimellä käynnissä oleva hoitojakso
        if ( period->patient_->get_id() == patient_name and !period->care_period_ended)
        {
            if (period->assigned_staff.find(staff_member_name)==period->assigned_staff.end())
            {
                Person* staff_object = staff_.find(staff_member_name)->second;
                period->add_staff(staff_member_name, staff_object);
                cout << STAFF_ASSIGNED << patient_name << endl;
                return;
            }
            // Jos hoitaja on jo hoitojaksolla, ei tehdä mitään.
            cout << STAFF_ASSIGNED << patient_name << endl;
            return;

        }
    }
}

void Hospital::add_medicine(Params params)
{
    std::string medicine = params.at(0);
    std::string strength = params.at(1);
    std::string dosage = params.at(2);
    std::string patient = params.at(3);
    if( not utils::is_numeric(strength, true) or
        not utils::is_numeric(dosage, true) )
    {
        std::cout << NOT_NUMERIC << std::endl;
        return;
    }
    std::map<std::string, Person*>::const_iterator
            patient_iter = current_patients_.find(patient);
    if( patient_iter == current_patients_.end() )
    {
        std::cout << CANT_FIND << patient << std::endl;
        return;
    }
    patient_iter->second->add_medicine(medicine, stoi(strength), stoi(dosage));
    std::cout << MEDICINE_ADDED << patient << std::endl;
}

void Hospital::remove_medicine(Params params)
{
    std::string medicine = params.at(0);
    std::string patient = params.at(1);
    std::map<std::string, Person*>::const_iterator
            patient_iter = current_patients_.find(patient);
    if( patient_iter == current_patients_.end() )
    {
        std::cout << CANT_FIND << patient << std::endl;
        return;
    }
    patient_iter->second->remove_medicine(medicine);
    std::cout << MEDICINE_REMOVED << patient << std::endl;
}

// Tulostaa yksittäisen potilaan tiedot.
// Ottaa paramterina halutun potilaan nimen
// Käyttää apufunktiona careperiod luokan print_for_patient
// metodia, sekä Persom luokan get- ja print_medicines.
void Hospital::print_patient_info(Params params)
{
    string patient_name = params.at(0);
    vector<CarePeriod*> patient_periods;

    for (CarePeriod* period : care_periods_)
    {
        if (period->patient_->get_id() == patient_name)
        {
            patient_periods.push_back(period);
        }
    }
    if (patient_periods.size()==0)
    {
        cout << CANT_FIND << patient_name << endl;
        return;
    }
    for (CarePeriod* period : patient_periods)
    {
        period->print_for_patient();
        cout << endl;
    }
    Person* patient_object = patient_periods.at(0)->patient_;
    if (patient_object->get_medicines().size() == 0)
    {
        cout << "* Medicines: None" << endl;
        return;
    }
    cout << "* Medicines:";
    patient_object->print_medicines("  - ");

}

// Tulostaa taas syötetyn henkilökunnan jäsenen hoitojaksotiedot,
// eli ne hoitojaksot, joissa on työskennellyt.
void Hospital::print_care_periods_per_staff(Params params)
{
    string staff_member_name = params.at(0);
    vector<CarePeriod*> periods;

    if (staff_.find(staff_member_name) == staff_.end())
    {
        cout << CANT_FIND << staff_member_name << endl;
        return;
    }
    for (auto period : care_periods_)
    {
        if (period->assigned_staff.begin()->first == staff_member_name)
        {
            periods.push_back(period);
        }
    }
    if (periods.size()==0)
    {
        cout << "None" << endl;
    }
    for (auto period : periods)
    {
        period->print_for_staff();
    }
}
// Tulostaa määrätyt lääkkeet, sekä henkilöt, joille
// lääkettä on määrätty. Funktiossa luodaan map, jossa
// set. Avaimina toimii lääkkeiden nimet ja payloadina
// set, johon tallennettuna potilaat, joille kyseistä
// lääkettä on määrätty.
void Hospital::print_all_medicines(Params)
{
    map<string, set<string>> medicine_data;
    for ( std::map<std::string, Person*>::iterator
              iter = all_patients.begin();
              iter != all_patients.end();
              ++iter)
    {
        // Jos potilaalla on määrättyjä lääkkeitä, niistä
        // luodaan avaimet mapille ja payloadiksi laitetaan
        // osoitin potilaan Person olioon.
        if (iter->second->get_medicines().size() != 0)
        {
            vector<string> patients_medicenes = iter->second->get_medicines();
            for (string medicine : patients_medicenes)
            {
                if (medicine_data.find(medicine) == medicine_data.end())
                {
                    set<string> name_data;
                    name_data.insert(iter->first);
                    medicine_data.insert(make_pair(medicine, name_data));
                    continue;
                }
                medicine_data.at(medicine).insert(iter->first);

            }
        }
    }

    if (medicine_data.size()==0)
    {
        cout << "None" << endl;
        return;
    }


    for (auto data : medicine_data)
    {
        cout << data.first << " prescribed for" << endl;
        for (auto name : data.second)
        {
            cout << "* " << name << endl;
        }
    }
}

void Hospital::print_all_staff(Params)
{
    if( staff_.empty() )
    {
        std::cout << "None" << std::endl;
        return;
    }
    for( std::map<std::string, Person*>::const_iterator iter = staff_.begin();
         iter != staff_.end();
         ++iter )
    {
        std::cout << iter->first << std::endl;
    }
}

// Kerää kaikkien potilaiden nimet mapin avaimiksi ja
// tallettaa payloadiksi vektorin, mihin sisällytetty
// potilaan hoitojaksot olioina. Tämän jälkeen tulostaa
// potilaiden nimet aakkosjärjestyksessä ja potilaan hoito-
// jaksot pysyvät lisäysjärjestyksessä.
void Hospital::print_all_patients(Params)
{
    std::map<string,vector<CarePeriod*>> all_care_periods_for_print;
    for ( std::map<std::string, Person*>::iterator
              iter = all_patients.begin();
              iter != all_patients.end();
              ++iter)
    {
        for (auto period : care_periods_)
        {
            if (period->patient_ == iter->second)
            {
                if (all_care_periods_for_print.find(iter->first)==
                        all_care_periods_for_print.end())
                {
                    vector<CarePeriod*> individual_care_periods;
                    individual_care_periods.push_back(period);
                    string patient_name = iter->first;
                    all_care_periods_for_print.insert(make_pair(patient_name, individual_care_periods));
                    continue;
                }
                all_care_periods_for_print.at(iter->first).push_back(period);
            }
        }
    }

    if (all_care_periods_for_print.size() == 0)
    {
        cout << "None" << endl;
        return;
    }

    for (auto patient : all_care_periods_for_print)
    {
        cout << patient.first << endl;
        for (auto period : patient.second)
        {
            period->print_for_patient();
            cout << endl;
        }
        if (patient.second.at(0)->patient_->get_medicines().size()==0)
        {
            cout << "* Medicines: None" << endl;
            continue;
        }
        cout << "* Medicines:";
        patient.second.at(0)->patient_->print_medicines("  - ");

    }
}
// Vastaava funktio kuin edellinen, nyt tulostetaan
// ainoastaan sairaalassa olevien potilaiden hoitojaksot.
void Hospital::print_current_patients(Params)
{
    {
        std::map<string,vector<CarePeriod*>> current_care_periods_for_print;
        for ( std::map<std::string, Person*>::iterator
                  iter = current_patients_.begin();
                  iter != current_patients_.end();
                  ++iter)
        {
            for (auto period : care_periods_)
            {
                if (period->patient_ == iter->second)
                {
                    if (current_care_periods_for_print.find(iter->first)==
                            current_care_periods_for_print.end())
                    {
                        vector<CarePeriod*> individual_care_periods;
                        individual_care_periods.push_back(period);
                        string patient_name = iter->first;
                        current_care_periods_for_print.insert(make_pair(patient_name, individual_care_periods));
                        continue;
                    }
                    current_care_periods_for_print.at(iter->first).push_back(period);
                }
            }
        }

        if (current_care_periods_for_print.size() == 0)
        {
            cout << "None" << endl;
            return;
        }

        for (auto patient : current_care_periods_for_print)
        {
            cout << patient.first << endl;
            for (auto period : patient.second)
            {
                period->print_for_patient();
            }
            cout << "* Medicines:" << endl;
            patient.second.at(0)->patient_->print_medicines("  - ");
        }
    }
}

void Hospital::set_date(Params params)
{
    std::string day = params.at(0);
    std::string month = params.at(1);
    std::string year = params.at(2);
    if( not utils::is_numeric(day, false) or
        not utils::is_numeric(month, false) or
        not utils::is_numeric(year, false) )
    {
        std::cout << NOT_NUMERIC << std::endl;
        return;
    }
    utils::today.set(stoi(day), stoi(month), stoi(year));
    std::cout << "Date has been set to ";
    utils::today.print();
    std::cout << std::endl;
}

void Hospital::advance_date(Params params)
{
    std::string amount = params.at(0);
    if( not utils::is_numeric(amount, true) )
    {
        std::cout << NOT_NUMERIC << std::endl;
        return;
    }
    utils::today.advance(stoi(amount));
    std::cout << "New date is ";
    utils::today.print();
    std::cout << std::endl;
}

