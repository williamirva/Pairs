/* Class CarePeriod
 * ----------
 * COMP.CS.110 SPRING 2021
 * ----------
 * Kuvaus:
 * Luokka, joka kuvaa yksittäistä hoitojaksoa. Hoitojaksolla
 * on aina alkamispäivä, sekä potilas lisäksi asetetaan päätymispäivä
 * hoitojakson päättyessä.
 *
 * Toiminnot:
 * SET_ENDING_DATE: asettaa hoitojakson alkamispäivän.
 * ADD_STAFF: Lisää henkiökunnan hoitojaksolle.
 * PRINT_FOR_PATIENT: Tulostus metodi, kun halutaan tiedot potilaalle
 * PRINT_FOR_STAFF: Tulostus metodi, kun halutaan tiedot henkilökunnalle
 *
 * Tekijä:
 *  * Tekijä:
 * Nimi: William Irva
 * Opiskelijanumero: 50087565
 * Käyttäjätunnus: qcwiir
 * E-Mail: william.irva@tuni.fi
 * */
#ifndef CAREPERIOD_HH
#define CAREPERIOD_HH

#include "person.hh"
#include "date.hh"
#include <string>

using namespace std;

class CarePeriod
{
public:
    // Constructor, start date given as a string (ddmmyyyy).
    CarePeriod(const std::string& start, Person* patient);

    // Constructor, start date given as a Date object.
    CarePeriod(const Date& start, Person* patient);

    // Destructor.
    ~CarePeriod();

    // More public methods
    void set_ending_date(Date date);

    // Lisää henkilökuntta hoitojaksolle
    void add_staff(string name, Person* object);

    // Tulostusfunktio, kun halutaan tulostaa
    // tietoja potilaan hoitojaksosta
    void print_for_patient();

    // Tulostusfunktio, kun halutaan tulostaa
    // tietoja hoitojaksosta, jossa henkilökunnan
    // jäsen on työskennellyt
    void print_for_staff();

    Person* patient_;
    bool care_period_ended = false;
    map<string, Person*> assigned_staff;

private:

    const Date start_;
    Date end_;


};

#endif // CAREPERIOD_HH
