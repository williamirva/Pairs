#include "careperiod.hh"
#include <iostream>

CarePeriod::CarePeriod(const std::string& start, Person* patient):
    patient_(patient), start_(start)
{
}

CarePeriod::CarePeriod(const Date &start, Person* patient):
    patient_(patient), start_(start)
{
}

CarePeriod::~CarePeriod()
{
}

void CarePeriod::set_ending_date(Date date)
{
    end_ = date;
}

void CarePeriod::add_staff(string name, Person* object)
{
    assigned_staff.insert({name, object});
}

// Tulostaa potilaan yksittäisen hoitojakson tiedot
void CarePeriod::print_for_patient()
{
    if (!care_period_ended)
    {
        cout << "* Care period: ";
        start_.print();
        cout << " -" << endl;
    }
    else if (care_period_ended)
    {
        cout << "* Care period: ";
        start_.print();
        cout << " - ";
        end_.print();
        cout << endl;
    }
    if (assigned_staff.size() == 0)
    {
    cout << "   - Staff: None";
        return;
    }
    cout <<"   - Staff:";
    for (auto staff : assigned_staff)
    {
        cout << " " << staff.first;
    }
}
// Tulostaa tiedot hoitojaksosta, jolle työntekijä
// on osallistunut.
void CarePeriod::print_for_staff()
{
    if (!care_period_ended)
    {
        start_.print();
        cout << " -" << endl;
    }
    else if (care_period_ended)
    {
        start_.print();
        cout << " - ";
        end_.print();
        cout << endl;
    }
    cout << "* Patient: ";
    patient_->print_id();
    cout << endl;
}
