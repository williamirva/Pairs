#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>

const std::string HELP_TEXT = "S = store id1 i2\nP = print id\n"
                              "C = count id\nD = depth id\n";


std::vector<std::string> split(const std::string& s, const char delimiter, bool ignore_empty = false){
    std::vector<std::string> result;
    std::string tmp = s;

    while(tmp.find(delimiter) != std::string::npos)
    {
        std::string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        if(not (ignore_empty and new_part.empty()))
        {
            result.push_back(new_part);
        }
    }
    if(not (ignore_empty and tmp.empty()))
    {
        result.push_back(tmp);
    }
    return result;
}

using Network = std::map<std::string, std::vector<std::string>>;

void store(Network& network, std::string hirer, std::string hiree)
{
    if (network.count(hirer) == 0)
    {
        network[hirer] = {};
    }
    if (network.count(hiree) == 0)
    {
        network[hiree] = {};
    }
    network.at(hirer).push_back(hiree);
}

void print(Network& network,std::string hirer, const int depth = 0)
{
    for (int i=0; i<depth; i++ )
    {
        std::cout << "..";
    }
    if (network.count(hirer) == 0)
    {
        std::cout << hirer <<std::endl;
    }
    else
    {
        std::cout << hirer <<std::endl;
        for (const std::string& hiree : network.at(hirer))
        {
            print(network, hiree, depth + 1);
        }
    }
}

int count(Network& network, std::string hirer, bool count_self = false)
{
    int hirees = 0;
    if (count_self)
    {
        hirees = 1;
    }
    for (const std::string& hiree : network.at(hirer))
    {
        hirees += count(network, hiree, true);
    }
    return hirees;
}

int depth(Network& network, std::string hirer, int network_depth = 1)
{
    int max_network_depth = network_depth;
    for (const std::string& hiree : network.at(hirer))
    {
        int hirees_depth = depth(network, hiree, network_depth + 1);
        if (hirees_depth > max_network_depth)
        {
            max_network_depth = hirees_depth;
        }
    }
    return max_network_depth;
}
int main()
{
    Network network;


    while(true){
        std::string line;
        std::cout << "> ";
        getline(std::cin, line);
        std::vector<std::string> parts = split(line, ' ', true);

        std::string command = parts.at(0);

        if(command == "S" or command == "s"){
            if(parts.size() != 3){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
                continue;
            }
            std::string id1 = parts.at(1);
            std::string id2 = parts.at(2);
            store(network, id1,id2);

        } else if(command == "P" or command == "p"){
            if(parts.size() != 2){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
                continue;
            }
            std::string id = parts.at(1);
            print(network, id);

        } else if(command == "C" or command == "c"){
            if(parts.size() != 2){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
                continue;
            }
            std::string id = parts.at(1);

            std::cout << count(network, id) << std::endl;

        } else if(command == "D" or command == "d"){
            if(parts.size() != 2){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
                continue;
            }
            std::string id = parts.at(1);

            std::cout << depth(network, id) << std::endl;

        } else if(command == "Q" or command == "q"){
           return EXIT_SUCCESS;
        } else {
            std::cout << "Erroneous command!" << std::endl << HELP_TEXT;
        }
    }
}
