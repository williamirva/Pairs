#include <iostream>

using namespace std;

bool IsValidExpression(string expression)
{
    if (!isdigit(expression.at(0)))
    {
        cout << "Error: Expression must start with a number" << endl;
        return false;
    }

    for (unsigned long i=0; i<expression.length(); ++i)
    {
        char c = expression.at(i);
        if (expression.at(i) == ' ' )
        {
            continue;
        }
        else if (isdigit(c))
        {
            continue;
        }
        else if(c=='+')
        {
            continue;
        }
        else if(c=='-')
        {
            continue;
        }
        else if(c=='*')
        {
            continue;
        }
        else if(c=='/')
        {
            continue;
        }
        else if(c=='#')
        {
            continue;
        }
        else
        {
            cout << "Error: Unknown character" << endl;
            return false;
        }
    }

    int number_of_operators = 0;
    int number_of_operands = 0;
    for (unsigned long i=0; i<expression.length(); ++i)
    {
        if (expression.at(i) == ' ')
        {
            continue;
        }
        else if (isdigit(expression.at(i)))
        {
            number_of_operands += 1;
        }
        else if (!isdigit(expression.at(i)))
        {
            number_of_operators += 1;
        }
    }

    if ( number_of_operands > number_of_operators)
    {
        cout << "Error: Too few operators" << endl;
        return false;
    }
    else if ( number_of_operands < number_of_operators)
    {
        cout << "Error: Too few operands" << endl;
        return  false;
    }
    else
    {
        return true;
    }
}

bool IsCapableToCalculate(string expression)
{
    int size_of_array = expression.length()/2;
    int operand_array[size_of_array];
    int* pointer = operand_array;
    for (unsigned long i=0; i < expression.length(); ++i)
    {
        char Char = expression.at(i);
        if (Char == ' ')
        {
            continue;
        }
        else if ( isdigit(Char) )
        {
            int number = (int)Char-48;
            *pointer = (number);
             pointer += 1;
        }
        else if (Char == '+')
        {
            pointer -= 1;
            *(pointer-1) = *(pointer-1) + *(pointer);
        }
        else if (Char == '-')
        {
            pointer -= 1;
           *(pointer-1) = *(pointer-1) - *(pointer);
        }
        else if (Char == '*')
        {
            pointer -= 1;
            *(pointer-1) = *(pointer-1) * *(pointer);
        }
        else if (Char == '/')
        {
            if(*(pointer-1) == 0)
            {
                cout << "Error: Division by zero" << endl;
                return false;
            }
            else
            {
                pointer -= 1;
                *(pointer-1) = *(pointer-1) / *(pointer);
            }
        }
        else if ( Char == '#')
        {
            cout << "Correct: " << *(pointer-1) << " is the result" << endl;
        }
    }
    return true;
}


int main()
{
    cout << "Input an expression in reverse Polish notation (end with #):" << endl;
    while(true)
    {
        string expression;
        cout << "EXPR> ";
        getline(cin, expression);
        if (IsValidExpression(expression))
        {
            if (IsCapableToCalculate(expression))
            {
                return EXIT_SUCCESS;
            }
            return EXIT_FAILURE;
        }
        return EXIT_FAILURE;
    }
}
