#include "array_operations.hh"



int greatest_v1(int *itemptr, int size)
{
    int greatest = *itemptr;

    for(int i=1; i<size; ++i)
    {
        int comparsion = *(itemptr+i);
        if (comparsion > greatest)
        {
            greatest = comparsion;
        }
    }
    return greatest;
}

int greatest_v2(int *itemptr, int *endptr)
{
    int greatest = *itemptr;

    for(int i=0; (itemptr+i)<endptr; ++i)
    {
        int comparsion = *(itemptr+i);
        if (comparsion > greatest)
        {
            greatest = comparsion;
        }
    }
    return greatest;
}

void copy(int *itemptr, int *endptr, int *targetptr)
{
    for(int i=0; (itemptr+i)!=endptr; ++i)
    {
        *(targetptr+i) = *(itemptr+i);
    }
}

void reverse(int *leftptr, int *rightptr)
{
    for(--rightptr; leftptr < rightptr; ++leftptr, --rightptr)
    {
        int tmp = *leftptr;
        *leftptr = *rightptr;
        *rightptr = tmp;
    }
}
