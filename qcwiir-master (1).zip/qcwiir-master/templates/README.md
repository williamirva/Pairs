Tähän hakemistoon kurssin henkilökunta tallentaa koodipohjia harjoituksia varten.

ÄLÄ TEE TÄHÄN HAKEMISTOON MITÄÄN MUUTOKSIA!

--------------------------

In this directory, course personnel will store template codes for the exercises.

DO NOT MAKE ANY MODIFICATIONS IN THIS DIRECTORY!
